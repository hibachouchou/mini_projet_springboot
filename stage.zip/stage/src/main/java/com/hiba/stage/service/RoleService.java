package com.hiba.stage.service;

import java.util.List;

import com.hiba.stage.entities.Role;



public interface RoleService {
	List<Role> getAllRoles();
	
}
